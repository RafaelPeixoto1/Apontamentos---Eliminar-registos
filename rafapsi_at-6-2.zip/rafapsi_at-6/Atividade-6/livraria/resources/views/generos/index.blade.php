@foreach($generos as $genero)
<li>
	<a href="{{route('generos.show',['id'
	=>$genero->id_genero])}}">
		{{$genero->designacao}}
	</a>

	<a href="{{route('generos.edit, ['id'=>$genero->id_genero])}}">Editar</a>

</li>
@endforeach
<ul>
	