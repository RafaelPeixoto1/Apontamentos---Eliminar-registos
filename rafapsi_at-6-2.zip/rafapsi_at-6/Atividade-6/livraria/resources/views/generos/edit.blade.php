<form action="{{route('generos.update', ['id'=>$genero->id_genero])}}" method="post">
@csrf
@method('patch')
Designacao: <input type="text" name="designacao" value="{{$genero->designcao}}"><br><br>
Observacoes: <input type="text" name="observacoes" value="{{$genero->observacoes"><br><br>

<input type="submit" value="Enviar">
</form>