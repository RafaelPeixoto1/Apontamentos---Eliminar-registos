<form action="{{route('livros.update', ['id'=>$livro->id_livro])}}" method="post">
@csrf
@method('patch')
Titulo: <input type="text" name="titulo" value="{{$livro->titulo}}"><br><br>
@if ($errors->has('titulo'))
Deverá indicar um títuloo válido<br>
@endif
Idioma: <input type="text" name="idioma" value=""><br><br>

Total paginas: <input type="text" name="total_paginas" value=""><br><br>
Data Edição: <input type="text" name="data_edicao" value=""><br><br>

ISBN: <input type="text" name="isbn" value=""><br><br>
@if ($errors->has('isbn'))<br><br>
Devera indicar um ISBN correto (13 carateres)
@endif
Observações: <textarea  name="observacoes"></textarea><br><br>
Imagem capa: <input type="text" name="imagem_capa"><br><br>
Genero:<input type="text" name="id_genero"><br><br>
Autor:<input type="text" name="id_autor"><br><br>
Sinopse:<textarea name="sinopse">{{$livro->sinopse)}}</textarea><br><br>
<input type="submit" value="Enviar">
</form>