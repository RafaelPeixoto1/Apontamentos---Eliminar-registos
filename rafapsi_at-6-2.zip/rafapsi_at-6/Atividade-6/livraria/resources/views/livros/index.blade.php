@foreach($livros as $livro)
<li>
	<a href="{{route('livros.show',['id'
	=>$livro->id_livro])}}">
		{{$livro->titulo}}
	</a>

<a href="{{route('livros.delete, ['id'=>$livro->id_livro])}}">Eliminar</a>


</li>
@endforeach
<ul>
	