<ul>
<?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<li>
<a href="<?php echo e(route('generos.show', ['id'=>$genero->id_genero])); ?>">
	<?php echo e($genero->designacao); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($generos->render()); ?><?php /**PATH C:\Users\Admin\Desktop\PSI-Atividade-5-main\Atividade-5\livraria\resources\views/generos/index.blade.php ENDPATH**/ ?>