ID:<?php echo e($genero->id_genero); ?><br>
Designação:<?php echo e($genero->designacao); ?><br>
Observações:<?php echo e($genero->observacoes); ?>

<?php /**PATH D:\rafapsi_at-6\Atividade-6\livraria\resources\views/generos/show.blade.php ENDPATH**/ ?>